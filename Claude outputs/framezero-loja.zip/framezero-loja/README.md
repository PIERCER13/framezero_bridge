# framezero — loja de scripts (Next.js + Tebex Headless API)

## Fluxo
1. A loja lista os pacotes da categoria `TEBEX_CATEGORY_NAME` pela Headless API.
2. O carrinho fica no navegador (localStorage). Não há login para navegar.
3. "Finalizar": `POST /api/checkout` → login do Discord (`/api/discord/login` → `/callback`).
4. `/api/checkout/finish` cria o basket na Tebex com `custom = { discord_id, discord_username }`, adiciona os pacotes e pede as opções de login da Tebex.
5. Depois do login da Tebex, `/api/checkout/go` redireciona para `links.checkout` (pagamento hospedado pela Tebex).

## Tebex: Escrow e Open Source
Crie **dois pacotes por script**, na categoria dos scripts, com o mesmo nome base:
`Meu Script — Escrow` e `Meu Script — Open Source`. A loja junta os dois num card só.

## Configuração
1. `cp .env.example .env.local` e preencha.
2. No app do Discord, adicione o redirect `SITE_URL/api/discord/callback`.
3. `npm install && npm run dev`.

## Entrega
O `discord_id` volta nos webhooks da Tebex. O bot do Discord (ou um endpoint seu) usa esse ID para liberar o cargo/arquivo.
Valide a assinatura do webhook conforme a documentação da Tebex.

## Pontos a conferir
- Caminhos de `getBasket` e `getAuthOptions` em `lib/tebex.ts` (confira em docs.tebex.io, Headless API).
- Se houver mais de uma opção de login da Tebex, hoje usamos a primeira.

## Idiomas
- Idiomas: pt-BR, pt-PT, en, es (`lib/i18n.ts`). URLs ficam como `/pt-BR`, `/en`...
- Detecção automática no `middleware.ts`: cookie `NEXT_LOCALE` (escolha do usuário) > cabeçalho `Accept-Language` do navegador > país (`x-vercel-ip-country` ou `cf-ipcountry`, se a hospedagem enviar) > inglês.
- Seletor de idioma no topo grava o cookie.
- Para adicionar outro idioma: inclua o código em `locales`, o nome em `localeNames`, o dicionário em `dicts` e, se quiser, a regra em `detectLocale`.
- Os textos de nome e descrição dos pacotes vêm da Tebex e ficam no idioma em que você cadastrou lá. Os preços vêm na moeda da loja.
