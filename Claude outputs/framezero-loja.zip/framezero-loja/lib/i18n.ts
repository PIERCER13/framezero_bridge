export const locales = ['pt-BR', 'pt-PT', 'en', 'es'] as const;
export type Locale = (typeof locales)[number];
export const defaultLocale: Locale = 'en';
export const isLocale = (v: string | undefined): v is Locale => !!v && (locales as readonly string[]).includes(v);

export const localeNames: Record<Locale, string> = { 'pt-BR': 'Português (BR)', 'pt-PT': 'Português (PT)', en: 'English', es: 'Español' };

// Escolhe o idioma pelo Accept-Language (o que o navegador do cliente declara).
// Se nada servir, usa o país (cabeçalho da hospedagem, ex.: x-vercel-ip-country).
export function detectLocale(acceptLanguage: string | null, country?: string | null): Locale {
  const prefs = (acceptLanguage ?? '')
    .split(',')
    .map((part) => {
      const [tag, q] = part.trim().split(';q=');
      return { tag: tag.toLowerCase(), q: q ? parseFloat(q) : 1 };
    })
    .filter((p) => p.tag)
    .sort((a, b) => b.q - a.q);

  for (const { tag } of prefs) {
    if (tag === 'pt-pt') return 'pt-PT';
    if (tag === 'pt-br' || tag === 'pt') return 'pt-BR';
    if (tag.startsWith('pt-')) return 'pt-PT'; // pt-AO, pt-MZ etc. seguem a norma europeia
    if (tag.startsWith('es')) return 'es';
    if (tag.startsWith('en')) return 'en';
  }

  const c = country?.toUpperCase();
  if (c === 'BR') return 'pt-BR';
  if (c && ['PT', 'AO', 'MZ', 'CV', 'GW', 'ST', 'TL'].includes(c)) return 'pt-PT';
  if (c && ['ES', 'MX', 'AR', 'CO', 'CL', 'PE', 'VE', 'EC', 'UY', 'PY', 'BO', 'CR', 'PA', 'DO', 'GT', 'HN', 'NI', 'SV', 'CU'].includes(c)) return 'es';
  return defaultLocale;
}

export type Dict = {
  cart: string; add: string; remove: string; close: string; empty: string; total: string; checkout: string;
  payNote: string; heroTitleA: string; heroTitleB: string; heroTitleC: string; heroText: string;
  licenseLabel: string; escrow: string; open: string; language: string; added: string; errors: Record<string, string>;
};

export const dicts: Record<Locale, Dict> = {
  'pt-BR': {
    cart: 'Carrinho', add: 'Adicionar', remove: 'Remover', close: 'Fechar', empty: 'Seu carrinho está vazio.', total: 'Total',
    checkout: 'Finalizar com Discord', payNote: 'O pagamento é feito na Tebex.',
    heroTitleA: 'Scripts para o seu ', heroTitleB: 'servidor', heroTitleC: ', em Escrow ou Open Source.',
    heroText: 'Monte o carrinho e entre com o Discord só na hora de finalizar.',
    licenseLabel: 'Tipo de licença', escrow: 'Escrow', open: 'Open Source', language: 'Idioma', added: 'Adicionado ao carrinho',
    errors: { discord: 'Não foi possível entrar com o Discord.', carrinho: 'Seu carrinho expirou. Tente novamente.', basket: 'Não foi possível criar o pedido.', checkout: 'Não foi possível abrir o pagamento.' },
  },
  'pt-PT': {
    cart: 'Carrinho', add: 'Adicionar', remove: 'Remover', close: 'Fechar', empty: 'O seu carrinho está vazio.', total: 'Total',
    checkout: 'Finalizar com Discord', payNote: 'O pagamento é feito na Tebex.',
    heroTitleA: 'Scripts para o seu ', heroTitleB: 'servidor', heroTitleC: ', em Escrow ou Open Source.',
    heroText: 'Monte o carrinho e inicie sessão com o Discord apenas ao finalizar.',
    licenseLabel: 'Tipo de licença', escrow: 'Escrow', open: 'Open Source', language: 'Idioma', added: 'Adicionado ao carrinho',
    errors: { discord: 'Não foi possível iniciar sessão com o Discord.', carrinho: 'O seu carrinho expirou. Tente novamente.', basket: 'Não foi possível criar a encomenda.', checkout: 'Não foi possível abrir o pagamento.' },
  },
  en: {
    cart: 'Cart', add: 'Add', remove: 'Remove', close: 'Close', empty: 'Your cart is empty.', total: 'Total',
    checkout: 'Checkout with Discord', payNote: 'Payment is handled by Tebex.',
    heroTitleA: 'Scripts for your ', heroTitleB: 'server', heroTitleC: ', in Escrow or Open Source.',
    heroText: 'Fill your cart and sign in with Discord only at checkout.',
    licenseLabel: 'License type', escrow: 'Escrow', open: 'Open Source', language: 'Language', added: 'Added to cart',
    errors: { discord: 'Could not sign in with Discord.', carrinho: 'Your cart expired. Please try again.', basket: 'Could not create the order.', checkout: 'Could not open the payment page.' },
  },
  es: {
    cart: 'Carrito', add: 'Añadir', remove: 'Quitar', close: 'Cerrar', empty: 'Tu carrito está vacío.', total: 'Total',
    checkout: 'Finalizar con Discord', payNote: 'El pago lo gestiona Tebex.',
    heroTitleA: 'Scripts para tu ', heroTitleB: 'servidor', heroTitleC: ', en Escrow u Open Source.',
    heroText: 'Arma tu carrito e inicia sesión con Discord solo al finalizar.',
    licenseLabel: 'Tipo de licencia', escrow: 'Escrow', open: 'Open Source', language: 'Idioma', added: 'Añadido al carrito',
    errors: { discord: 'No se pudo iniciar sesión con Discord.', carrinho: 'Tu carrito caducó. Inténtalo de nuevo.', basket: 'No se pudo crear el pedido.', checkout: 'No se pudo abrir el pago.' },
  },
};
