import { getCategories, type TebexPackage } from './tebex';

// Convenção de nomes na Tebex: "Nome do script — Escrow" e "Nome do script — Open Source".
// Os dois pacotes com o mesmo nome base viram um único card com seletor de licença.
export type Script = {
  slug: string; name: string; description: string; image: string | null; currency: string;
  escrow?: { id: string; price: number }; open?: { id: string; price: number };
};

const SUFFIX = /\s*[—–-]\s*(escrow|open ?source)\s*$/i;

export async function getScripts(): Promise<Script[]> {
  const wanted = (process.env.TEBEX_CATEGORY_NAME ?? 'Scripts').toLowerCase();
  const cats = await getCategories();
  const pkgs: TebexPackage[] = cats.filter((c) => c.name.toLowerCase() === wanted).flatMap((c) => c.packages);
  const map = new Map<string, Script>();
  for (const p of pkgs) {
    const m = p.name.match(SUFFIX);
    const base = p.name.replace(SUFFIX, '').trim();
    const s = map.get(base) ?? { slug: base.toLowerCase().replace(/\W+/g, '-'), name: base, description: p.description, image: p.image, currency: p.currency };
    const entry = { id: String(p.ident ?? p.id), price: p.total_price };
    if (m && /^open/i.test(m[1])) s.open = entry; else s.escrow = entry;
    map.set(base, s);
  }
  return [...map.values()];
}
