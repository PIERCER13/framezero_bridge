// Cliente mínimo da Tebex Headless API. Só roda no servidor.
const BASE = 'https://headless.tebex.io/api';
const token = () => {
  const t = process.env.TEBEX_PUBLIC_TOKEN;
  if (!t) throw new Error('TEBEX_PUBLIC_TOKEN não definido');
  return t;
};

async function call<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    ...init,
    headers: { 'Content-Type': 'application/json', Accept: 'application/json', ...init?.headers },
    cache: 'no-store',
  });
  if (!res.ok) throw new Error(`Tebex ${res.status} em ${path}: ${await res.text()}`);
  return res.json() as Promise<T>;
}

export type TebexPackage = {
  id: number; ident?: string; name: string; description: string; image: string | null;
  total_price: number; currency: string;
};
export type TebexCategory = { id: number; name: string; packages: TebexPackage[] };
export type TebexBasket = { ident: string; username: string | null; links?: { checkout?: string }; packages: unknown[] };

export async function getCategories(): Promise<TebexCategory[]> {
  const r = await call<{ data: TebexCategory[] }>(`/accounts/${token()}/categories?includePackages=1`);
  return r.data;
}

export async function createBasket(body: {
  complete_url: string; cancel_url: string; custom?: Record<string, string>;
}): Promise<TebexBasket> {
  const r = await call<{ data: TebexBasket }>(`/accounts/${token()}/baskets`, { method: 'POST', body: JSON.stringify(body) });
  return r.data;
}

export async function addPackage(basketIdent: string, packageId: string, quantity: number, custom?: Record<string, string>) {
  return call(`/accounts/${token()}/${basketIdent}/packages`, {
    method: 'POST',
    body: JSON.stringify({ package_id: packageId, quantity, custom }),
  });
}

export async function getBasket(basketIdent: string): Promise<TebexBasket> {
  const r = await call<{ data: TebexBasket }>(`/accounts/${token()}/baskets/${basketIdent}`);
  return r.data;
}

// Opções de login da Tebex (Cfx.re, Steam, etc.). Vazio = a loja não exige.
export async function getAuthOptions(basketIdent: string, returnUrl: string): Promise<{ name: string; url: string }[]> {
  return call(`/accounts/${token()}/baskets/${basketIdent}/auth?returnUrl=${encodeURIComponent(returnUrl)}`);
}
