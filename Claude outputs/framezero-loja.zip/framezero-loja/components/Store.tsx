'use client';
import { useEffect, useState } from 'react';
import type { Script } from '@/lib/catalog';
import { locales, localeNames, type Dict, type Locale } from '@/lib/i18n';

type Lic = 'escrow' | 'open';
type Line = { id: string; name: string; lic: Lic; price: number; qty: number };

export default function Store({ scripts, locale, t, error }: { scripts: Script[]; locale: Locale; t: Dict; error?: string }) {
  const brl = (v: number, cur = 'BRL') => new Intl.NumberFormat(locale, { style: 'currency', currency: cur }).format(v);
  const changeLocale = (l: string) => { document.cookie = `NEXT_LOCALE=${l}; path=/; max-age=31536000; samesite=lax`; window.location.href = `/${l}`; };
  const [sel, setSel] = useState<Record<string, Lic>>({});
  const [cart, setCart] = useState<Line[]>([]);
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => { try { setCart(JSON.parse(localStorage.getItem('fz_cart') ?? '[]')); } catch {} }, []);
  useEffect(() => { localStorage.setItem('fz_cart', JSON.stringify(cart)); }, [cart]);

  const add = (s: Script) => {
    const lic = sel[s.slug] ?? (s.escrow ? 'escrow' : 'open');
    const opt = lic === 'escrow' ? s.escrow : s.open;
    if (!opt) return;
    setCart((c) => c.some((l) => l.id === opt.id) ? c : [...c, { id: opt.id, name: `${s.name} (${lic === 'escrow' ? t.escrow : t.open})`, lic, price: opt.price, qty: 1 }]);
    setOpen(true);
  };
  const remove = (id: string) => setCart((c) => c.filter((l) => l.id !== id));
  const total = cart.reduce((a, l) => a + l.price * l.qty, 0);

  const checkout = async () => {
    setBusy(true);
    const r = await fetch('/api/checkout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ items: cart.map((l) => ({ id: l.id, qty: l.qty })) }) });
    const { url } = await r.json();
    window.location.href = url; // vai para o Discord, depois Tebex
  };

  return (
    <>
      <header className="top">
        <strong className="logo">frame<span>zero</span></strong>
        <div className="row">
          <select aria-label={t.language} value={locale} onChange={(e) => changeLocale(e.target.value)}>
            {locales.map((l) => <option key={l} value={l}>{localeNames[l]}</option>)}
          </select>
          <button className="btn" onClick={() => setOpen(true)}>{t.cart} ({cart.length})</button>
        </div>
      </header>

      <section className="hero">
        {error && <p role="alert" className="alert">{error}</p>}
        <h1>{t.heroTitleA}<span>{t.heroTitleB}</span>{t.heroTitleC}</h1>
        <p>{t.heroText}</p>
      </section>

      <main className="grid">
        {scripts.map((s) => {
          const lic = sel[s.slug] ?? (s.escrow ? 'escrow' : 'open');
          const opt = lic === 'escrow' ? s.escrow : s.open;
          return (
            <article key={s.slug} className="card">
              <div className="thumb">{s.image && <img src={s.image} alt="" />}</div>
              <h3>{s.name}</h3>
              <div className="desc" dangerouslySetInnerHTML={{ __html: s.description }} />
              <div className="seg" role="group" aria-label={t.licenseLabel}>
                {s.escrow && <button aria-pressed={lic === 'escrow'} onClick={() => setSel({ ...sel, [s.slug]: 'escrow' })}>{t.escrow}</button>}
                {s.open && <button aria-pressed={lic === 'open'} onClick={() => setSel({ ...sel, [s.slug]: 'open' })}>{t.open}</button>}
              </div>
              <div className="row">
                <b>{opt ? brl(opt.price, s.currency) : '—'}</b>
                <button className="btn" onClick={() => add(s)}>{t.add}</button>
              </div>
            </article>
          );
        })}
      </main>

      {open && (
        <aside className="drawer" aria-label={t.cart}>
          <div className="row"><h2>{t.cart}</h2><button className="ghost" onClick={() => setOpen(false)}>{t.close}</button></div>
          {cart.length === 0 && <p className="muted">{t.empty}</p>}
          {cart.map((l) => (
            <div key={l.id} className="row line"><span>{l.name}</span><span>{brl(l.price)} <button className="ghost" onClick={() => remove(l.id)}>{t.remove}</button></span></div>
          ))}
          {cart.length > 0 && (
            <>
              <div className="row"><b>{t.total}</b><b>{brl(total)}</b></div>
              <button className="btn wide" disabled={busy} onClick={checkout}>{t.checkout}</button>
              <p className="muted">{t.payNote}</p>
            </>
          )}
        </aside>
      )}
    </>
  );
}
