import { NextResponse, type NextRequest } from 'next/server';
import { detectLocale, isLocale } from '@/lib/i18n';

// Sem prefixo de idioma na URL? Escolhe um (cookie > Accept-Language > país) e redireciona.
export function middleware(req: NextRequest) {
  const { pathname, search } = req.nextUrl;
  const first = pathname.split('/')[1];
  if (isLocale(first)) return NextResponse.next();

  const saved = req.cookies.get('NEXT_LOCALE')?.value;
  const locale = isLocale(saved)
    ? saved
    : detectLocale(req.headers.get('accept-language'), req.headers.get('x-vercel-ip-country') ?? req.headers.get('cf-ipcountry'));

  const url = req.nextUrl.clone();
  url.pathname = `/${locale}${pathname === '/' ? '' : pathname}`;
  url.search = search;
  const res = NextResponse.redirect(url);
  res.cookies.set('NEXT_LOCALE', locale, { path: '/', maxAge: 60 * 60 * 24 * 365, sameSite: 'lax' });
  return res;
}

export const config = { matcher: ['/((?!api|_next|.*\\..*).*)'] };
