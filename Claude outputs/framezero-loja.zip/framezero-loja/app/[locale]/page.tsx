import { notFound } from 'next/navigation';
import { getScripts } from '@/lib/catalog';
import { dicts, isLocale } from '@/lib/i18n';
import Store from '@/components/Store';

export const dynamic = 'force-dynamic';

export default async function Page({ params, searchParams }: { params: Promise<{ locale: string }>; searchParams: Promise<{ erro?: string }> }) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const { erro } = await searchParams;
  const scripts = await getScripts();
  return <Store scripts={scripts} locale={locale} t={dicts[locale]} error={erro ? dicts[locale].errors[erro] : undefined} />;
}
