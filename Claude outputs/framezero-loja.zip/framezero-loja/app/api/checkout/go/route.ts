import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { getBasket } from '@/lib/tebex';

// 3) Volta do login da Tebex: pegamos o link de pagamento do basket e enviamos o cliente.
export async function GET(req: Request) {
  const site = process.env.SITE_URL!;
  const ident = new URL(req.url).searchParams.get('basket');
  if (!ident) return NextResponse.redirect(`${site}/?erro=basket`);
  const basket = await getBasket(ident);
  const checkout = basket.links?.checkout;
  if (!checkout) return NextResponse.redirect(`${site}/?erro=checkout`);
  (await cookies()).delete('fz_cart');
  return NextResponse.redirect(checkout);
}
