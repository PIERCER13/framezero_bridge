import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { sign, cookieOpts } from '@/lib/session';

// 1) O navegador manda o carrinho (ids de pacotes da Tebex). Guardamos num cookie assinado
//    e mandamos o usuário para o login do Discord, que só acontece aqui, no checkout.
export async function POST(req: Request) {
  const { items } = (await req.json()) as { items: { id: string; qty: number }[] };
  const clean = (items ?? []).filter((i) => i.id && i.qty > 0 && i.qty <= 10).slice(0, 50);
  if (!clean.length) return NextResponse.json({ error: 'Carrinho vazio' }, { status: 400 });
  (await cookies()).set('fz_cart', sign({ items: clean }), cookieOpts);
  return NextResponse.json({ url: '/api/discord/login' });
}
