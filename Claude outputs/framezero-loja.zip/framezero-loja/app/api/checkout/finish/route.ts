import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { verify } from '@/lib/session';
import { isLocale, defaultLocale } from '@/lib/i18n';
import { createBasket, addPackage, getAuthOptions } from '@/lib/tebex';

// 2) Com o Discord confirmado, criamos o basket na Tebex já com o ID do Discord em `custom`
//    (ele volta nos webhooks, para o bot saber quem comprou) e mandamos para o login da Tebex.
export async function GET() {
  const site = process.env.SITE_URL!;
  const jar = await cookies();
  const saved = jar.get('NEXT_LOCALE')?.value;
  const loc = isLocale(saved) ? saved : defaultLocale;
  const cart = verify<{ items: { id: string; qty: number }[] }>(jar.get('fz_cart')?.value);
  const discord = verify<{ id: string; username: string }>(jar.get('fz_discord')?.value);
  if (!cart) return NextResponse.redirect(`${site}/?erro=carrinho`);
  if (!discord) return NextResponse.redirect(`${site}/api/discord/login`);

  const custom = { discord_id: discord.id, discord_username: discord.username };
  const basket = await createBasket({ complete_url: `${site}/${loc}?compra=ok`, cancel_url: `${site}/${loc}?compra=cancelada`, custom });
  for (const item of cart.items) await addPackage(basket.ident, item.id, item.qty, custom);

  const goUrl = `${site}/api/checkout/go?basket=${basket.ident}`;
  const options = await getAuthOptions(basket.ident, goUrl);
  // Se a Tebex não pedir login (ou só houver uma opção), seguimos direto.
  if (options.length) return NextResponse.redirect(options[0].url);
  return NextResponse.redirect(goUrl);
}
