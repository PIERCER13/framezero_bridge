import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { sign, cookieOpts } from '@/lib/session';

export async function GET(req: Request) {
  const url = new URL(req.url);
  const jar = await cookies();
  const code = url.searchParams.get('code');
  if (!code || url.searchParams.get('state') !== jar.get('fz_state')?.value) {
    return NextResponse.redirect(`${process.env.SITE_URL}/?erro=discord`);
  }
  jar.delete('fz_state');

  const tokenRes = await fetch('https://discord.com/api/oauth2/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: process.env.DISCORD_CLIENT_ID!,
      client_secret: process.env.DISCORD_CLIENT_SECRET!,
      grant_type: 'authorization_code',
      code,
      redirect_uri: `${process.env.SITE_URL}/api/discord/callback`,
    }),
  });
  if (!tokenRes.ok) return NextResponse.redirect(`${process.env.SITE_URL}/?erro=discord`);
  const { access_token } = (await tokenRes.json()) as { access_token: string };

  const me = await fetch('https://discord.com/api/users/@me', { headers: { Authorization: `Bearer ${access_token}` } });
  if (!me.ok) return NextResponse.redirect(`${process.env.SITE_URL}/?erro=discord`);
  const user = (await me.json()) as { id: string; username: string };

  jar.set('fz_discord', sign({ id: user.id, username: user.username }), cookieOpts);
  return NextResponse.redirect(`${process.env.SITE_URL}/api/checkout/finish`);
}
