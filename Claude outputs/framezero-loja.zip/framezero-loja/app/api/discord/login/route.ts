import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { randomBytes } from 'node:crypto';
import { cookieOpts } from '@/lib/session';

export async function GET() {
  const state = randomBytes(16).toString('hex');
  (await cookies()).set('fz_state', state, cookieOpts);
  const url = new URL('https://discord.com/oauth2/authorize');
  url.searchParams.set('client_id', process.env.DISCORD_CLIENT_ID!);
  url.searchParams.set('redirect_uri', `${process.env.SITE_URL}/api/discord/callback`);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('scope', 'identify');
  url.searchParams.set('state', state);
  return NextResponse.redirect(url);
}
